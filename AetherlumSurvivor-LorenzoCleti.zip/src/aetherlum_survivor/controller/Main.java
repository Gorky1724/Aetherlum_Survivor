package aetherlum_survivor.controller;

public class Main {

    public static void main(String[] args) {
        Controller.getInstance().startApplication();
    }
    
}
