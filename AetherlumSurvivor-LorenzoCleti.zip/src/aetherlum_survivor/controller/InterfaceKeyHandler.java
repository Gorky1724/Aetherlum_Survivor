package aetherlum_survivor.controller;

public interface InterfaceKeyHandler {
    
    //getter for directions pressed
    public boolean getUpPressed();

    public boolean getRightPressed();

    public boolean getDownPressed();

    public boolean getLeftPressed();

    //reset keys
    public void resetKeys();
}
